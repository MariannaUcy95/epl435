<?php 
    //require_once('./mysqli_connect.php');
    $link = mysqli_connect('localhost', 'root', ''); 
    if (!$link) 
    { 
        $output = 'Unable to connect to the database server.'; 
        exit(); 
    }

    $query=SELECT CName FROM COURSE;
    $response=mysqli_query($dbc,$query);
    if($response){
	   echo '<table align="center" cellspacing="5" cellpadding="8"> <tr><td align = "center">';

	   while($row=mysqli_fetch_array($response)){
		  echo '<tr><td align="center">'. 
		  $row['name'].'</td>';
		  echo '</tr>';
	   }
	   echo '</table>';
	   }
	   else{
		  echo "Couldnt issue db query<br>";
	   echo mysqli_error($dbc);
	   }
    mysqli_close($dbc);
?>