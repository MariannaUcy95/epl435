<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<!-- THIS IS THE PAGE FOR THE TEACHER TO IDENTIFY ITSELF, THE ID USED FOR THE "CURRENT SESSION" WILL DEFINE THE CONTENT OF ALL THE FOLLOWING TEACHER PAGES -->

<head>

<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
<link rel="stylesheet" type="text/css" href="myCSS.css" />

</head>

<body>
<img src="logoW.png" height="90" width="122" id="logo"> 
<br />
<br />
<br />
<br />
<br />

<div class="titleBox"><h1>Identify yourself</h1></div>
<!-- So this is the hard part, the user enter the value of two variable uname and psw,
somehow it has to be linked to a method (which may not be post i don't know), and an
action (it is supposed to lead to the Selectiong Course page, but I guess some stuff
need to be done first I don't  -->
<form method="post" action="teacher_select_course.html">
    <center><p>username  <input type="text" name="uname" required></center></p>

    <center><p>password  <input type="password" name="psw" required></center></p>
	<br />

	<!-- I put the submit button out of the screen because it's better looking that way,
I would like the user to press Enter to submit its identifiers but for now it only works
when the cursor is still in one of the two input field, otherwise it doesn't work, I saw online that you can do a javascript method so that wherever the user cursor is on the page you can 
trigger the submit button when he presses Enter -->
	<center><button style="position: absolute; left: -9999px; width: 1px; height: 1px;"tabindex="-1" class="button buttonBottom" type="submit">Next</button></center>

</form>


</body>

</html>
