<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
<link rel="stylesheet" type="text/css" href="myCSS.css" />
    
</head>

<body>

<span title="HOME PAGE"><img src="logoW.png" height="90" width="122" id="logo"></span>

<header class="w3-container w3-teal">
    <a href="select_course.php"><h2>Home</h2></a>
    <?php
    session_start();
    $qcode = $_GET['question'];
    if(isset($_SESSION['type'])) { ?>
        <center><a href="logout.php" class="button buttonTop buttonHead">Log out</a></center>
    <?php } ?>
</header>

<img src="logoW.png" height="90" width="122" id="logo"> 
<div class="titleBox"><h1>Select the correct answer</h1></div>

<table class="tableone">
    <thead>
        <tr>
          <th class="codeElement" scope="col">CODE</th> 
          <th class="textElement" scope="col">ANSWER</th>
        </tr>
    </thead>
    <tbody>
    <tr><td colspan="2">
        <div class="innerb">
	
            <table class="tabletwo">
                <thead></thead>
                    <?php
                        $servername = "localhost";
                        $username = "root";
                        $password = "";
                        $dbname = "epl425";
                        // Create connection
                        $conn = new mysqli($servername, $username, $password, $dbname);
                        // Check connection
                        if ($conn->connect_error) {
                            die("Connection failed: " . $conn->connect_error);
                        }
                        mysqli_query($conn,"SET NAMES utf8");
                        $sql = "SELECT * FROM possible_answer WHERE possible_answer.QCode='$qcode'";
                        $result = mysqli_query($conn, $sql);
                        if (mysqli_num_rows($result)==true){
                            // output data of each row
                            while($row = mysqli_fetch_assoc($result)) {
                                echo "<tr><td><a ".$row["AnswerNo"]."'>".$row["AnswerNo"]."</a></td>
                                <td><a ".$row["Description"]."'>".$row["Description"]."</a></td></tr>";
                            }
                        }
                    ?>    
            </table>
        </div>
        </td></tr>
    </tbody>
</table>

<center><a href="select_answer.php" class="button buttonBottom" style="bottom=10%;">Next</a></center>

</body>

</html>
