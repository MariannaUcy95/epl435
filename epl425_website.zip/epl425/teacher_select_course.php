<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<!-- THIS PAGE IT THE TEACHER PAGE TO CHOOSE A COURSE -->

<head>

<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
<link rel="stylesheet" type="text/css" href="myCSS.css" />
    
</head>

<body>

<a href="teacher_select_course.html"><span title="HOME PAGE"><img src="logoW.png" height="90" width="122" id="logo"> </span></a>
<header class="w3-container w3-teal">

<h2>Home</h2>

<!-- When this button is pressed, the user goes back to the Identifying page but it should
also, I guess, somehow end the "session" of the user and reset the "current user id", I
don't know how you could do that -->
<a href="teacher_identify_yourself.html" class="button buttonTop buttonHead">Log out</a></center>

</header>
<img src="logoW.png" height="90" width="122" id="logo"> 
<div class="titleBox"><h1>Select a course</h1></div>

<!-- This is the table of course, I made it responsive so that if there's a lot of courses
to show you can scroll down to see it -->
<table class="tableone">
      <thead>
        <tr>
          <th class="codeElement" scope="col">CODE</th> 
          <th class="textElement" scope="col">COURSE</th>
        </tr>
      </thead>
<tbody>
<tr><td colspan="2">
<div class="innerb">
	<!-- IMPORTANT this is where, according to the current teacher id for this session, a call
to the database must be done to show his courses -->
	<!-- Also: a javascript function should be done to be able to select in the table the
wanted course, and then save it somewhere in the "current session" -->
<table class="tabletwo">
    <thead></thead>
    <?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "epl425";
        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);
        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        $sql = "SELECT CCode,Title FROM course";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result)==true){
            // output data of each row
            while($row = mysqli_fetch_assoc($result)) {
                echo "<tr><td>".$row["CCode"]."</td><td>".$row["Title"]."</td></tr>";
            }
        }
    ?>    
</table>
</div>
</td></tr>
</tbody>
</table>

<!-- Here when the teacher press next it should go to the select lecture page, and in this
page the content will be set according to the selected course -->
<center><a href="teacher_select_lecture.html" class="button buttonBottom" style="bottom=10%;">Next</a></center>

</body>

</html>
