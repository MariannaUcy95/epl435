<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html" charset="ISO-8859-1" />
<link rel="stylesheet" type="text/css" href="myCSS.css" />

<script>
function hideShowDivs(hideDiv, showDiv) {
    var x = document.getElementById(hideDiv);
    x.style.display = "none"; 
    var y = document.getElementById(showDiv);
    y.style.display = "block";
}
</script>

<script>
function showErrorMessage() {
	alert("Your username or password is incorrect!");
	
}
</script>

</head>

<body>

<?php
	session_start();
	if(isset($_SESSION['error'])) { ?>
		<script type='text/javascript'>
			showErrorMessage();
		</script>
		<?php unset($_SESSION['error']);
	}
?>

<div id="div_1">
	<img src="logoB.png" id="logoPrincipal"> 
	<center><button class="button buttonBottom" style="bottom:10%; left:40%;" onclick="hideShowDivs('div_1', 'div_2')">ENTER THE WEBSITE</button></center>
</div>

<div id="div_2" style="display: none;">
	<div class="titleBox"><h1>What are you?</h1></div>
	<center><a href="select_course.php" class="button buttonTop">Student</a></center>
	<br>
	<center><button class="button buttonTop" onclick="hideShowDivs('div_2', 'div_3')">Teacher</button></center>
</div>

<div id="div_3" style="display: none;">
	<img src="logoW.png" height="90" width="122" id="logo"> 
	<br/>
	<br/>
	<br/>
	<br/>
	<br/>
	<div class="titleBox"><h1>Identify yourself</h1></div>
	<form method="post" action="login.php">
    	<center><p>Username  <input type="text" name="Username" required></center></p>
    	<center><p>Password  <input type="password" name="Password" required></center></p> 
		<br/>
		<center><button style="position: absolute; left: -9999px; width: 1px; height: 1px;" tabindex="-1" class="button buttonBottom" type="submit">Next</button></center>
		<div id="div_4" style="color: red; display: none;">
			Your username or password is incorrect!
		</div>
		<center><button class="button buttonBottom" type="submit" style="bottom:10%;">Log In</button></center>
	</form>
</div>

<div id="div_4" style="display: none;">

</div>

</body>

</html>
